close all
clc

%% Signal

F_S = figure('units','normalized','outerposition',[0 0 1 1]);
for i = 1:25:length(t)
    subplot(3,1,1)
    plot(xR(2:end-1)-dx,uL(:,i)*1e6,'linewidth',5,'color',[0.5 0.5 0.5])
    grid on
    hold on
    line([xR(mR-mG+1) xR(mR-mG+1)],[1.2*min(min(uL))*1e6 1.2*max(max(uL))*1e6],'Color','k','LineStyle','--')
    line([xR(mR-1-ideb)-dx xR(mR-1-ideb)-dx],[1.2*min(min(uL))*1e6 1.2*max(max(uL))*1e6],'Color','k','LineStyle','--')
    line([xR(mR-1)-dx xR(mR-1)-dx],[1.2*min(min(uL))*1e6 1.2*max(max(uL))*1e6],'Color','k','LineStyle','--')
    hold off
    xlim([0 1.3])
    ylim([1.2*min(min(uL))*1e6 1.2*max(max(uL))*1e6])
    set(gca,'fontsize',20)
    set(gca,'XTickLabel','')
    subplot(3,1,2)
    plot(0.6+xG(2:end-1)-dx,uG(:,i)*1e6,'linewidth',5,'color',[240 100 10]/256)
    grid on
    hold on
    line([xR(mR-mG+1) xR(mR-mG+1)],[1.2*min(min(uG))*1e6 1.2*max(max(uG))*1e6],'Color','k','LineStyle','--')
    line([xR(mR-1-ideb)-dx xR(mR-1-ideb)-dx],[1.2*min(min(uG))*1e6 1.2*max(max(uG))*1e6],'Color','k','LineStyle','--')
    line([xR(mR-1)-dx xR(mR-1)-dx],[1.2*min(min(uG))*1e6 1.2*max(max(uG))*1e6],'Color','k','LineStyle','--')
    hold off
    xlim([0 1.3])
    ylim([1.2*min(min(uG))*1e6 1.2*max(max(uG))*1e6])
    set(gca,'fontsize',20)
    set(gca,'XTickLabel','')
    ylabel('Amplitude [\mum]')
    subplot(3,1,3)
    plot(0.6+xR(2:end-1)-dx,uR(:,i)*1e6,'linewidth',5,'color',[0.5 0.5 0.5])
    grid on
    hold on
    line([xR(mR-mG+1) xR(mR-mG+1)],[1.2*min(min(uR))*1e6 1.2*max(max(uR))*1e6],'Color','k','LineStyle','--')
    line([xR(mR-1-ideb)-dx xR(mR-1-ideb)-dx],[1.2*min(min(uR))*1e6 1.2*max(max(uR))*1e6],'Color','k','LineStyle','--')
    line([xR(mR-1)-dx xR(mR-1)-dx],[1.2*min(min(uR))*1e6 1.2*max(max(uR))*1e6],'Color','k','LineStyle','--')
    hold off
    xlim([0 1.3])
    ylim([1.2*min(min(uR))*1e6 1.2*max(max(uR))*1e6])
    set(gca,'fontsize',20)
    xlabel('x [m]')
    pause(0.02)
end

PAB1 = msgbox('Click OK and Press any button to Continue');
pause
close(F_S)

F_S = figure('units','normalized','outerposition',[0 0 1 1]);
subplot(2,1,1)
plot(t*1e6,uL(fS(1),:)*1e6,'k','linewidth',2)
set(gca,'fontsize',25)
ylabel('Input Amplitude [{\mu}m]')
set(gca,'XTick','')
set(gca,'XTickLabel','')
subplot(2,1,2)
plot(t*1e6,uR(fR(1),:)*1e6,'k','linewidth',2)
xlabel('Time [{\mu}s]')
ylabel('Output Amplitude [{\mu}m]')
set(gca,'fontsize',25)
set(gcf,'PaperOrientation','landscape')
set(gcf,'PaperUnits','Normalized')
set(gcf,'PaperPosition',[0.01,0.01,1,1])
set(gcf,'PaperPositionMode','Manual')
print(F_S,'-dpdf','-r300',strcat('Results/Signals_',num2str(deb*1000),'mm-',num2str(f/1000),'kHz.pdf'));

PAB2 = msgbox('Click OK and Press any button to Continue');
pause
close(F_S)

%% Spectrogram

N = length(uR(fR(1),:));
T = t(2);
Nb = 5;
Ncamp = round(Nb/f/T);
Ncamp90 = round(0.99*Ncamp);
Fs = 1/T;

F_SP = figure('units','normalized','outerposition',[0 0 1 1]);
spectrogram(10000*uR(fR(1),:),hamming(Ncamp),Ncamp90,0*f:5*f/1000:2*f,Fs);
title('Check the "Hole Time" and Press any button to Continue')
xlim([0 2*f/1000])
cb = colorbar;
cb.Label.String = 'PSD [dB/Hz]';
xlabel('Frequency [kHz]')
ylabel('Time [{\mu}s]')
set(gca,'fontsize',20)
dcm = datacursormode;
dcm.Enable = 'on';

pause
opts.Interpreter = 'tex';
prompt = {'Enter Hole Time [{\mu}s]:'};
dlgtitle = 'Input';
dims = [1 35];
definput = {'0'};
thole = 1e-6*str2double(cell2mat(inputdlg(prompt,dlgtitle,dims,definput,opts)));

clf(F_SP)

axes('Position',[0.1,0.575,0.85,0.4])
box on
[s,ff,tt] = spectrogram(10000*uR(fR(1),:),hamming(Ncamp),Ncamp90,0*f:5*f/1000:2*f,1/T);
spectrogram(10000*uR(fR(1),:),hamming(Ncamp),Ncamp90,0*f:5*f/1000:2*f,Fs);
xlim([0 2*f/1000])
ylim([0 100])
colorbar('OFF')
cb=colorbar;
cb.Label.String = 'PSD [dB/Hz]';
cb.Location = 'east';
cb.Color = 'w';
xlabel('')
ylabel('Time [{\mu}s]')
set(gca,'XTick','')
set(gca,'XTickLabel','')
set(gca,'fontsize',25)
axes('Position',[0.1,0.15,0.85,0.4])
box on
tstar = find(abs(tt-thole)<(tt(2)-tt(1))/2);	
psdx = (T/N)*abs(s(:,tstar)).^2;		
psdx(2:end-1) = 2*psdx(2:end-1);
logpsdx = 10*log10(psdx/min(psdx));
plot((ff)/1000,10*log10(psdx),'linewidth',2,'color','k')
ylabel('PSD [dB/Hz]')
xlabel('Frequency [kHz]')
xlim([0 2*f/1000])
set(gca,'fontsize',25)
set(gcf,'PaperOrientation','landscape')
set(gcf,'PaperUnits','Normalized')
set(gcf,'PaperPosition',[0.01,0.01,1,1])
set(gcf,'PaperPositionMode','Manual')
print(F_SP,'-dpdf','-r300',strcat('Results/Spectrogram_',num2str(deb*1000),'mm-',num2str(f/1000),'kHz.pdf'));